async function getWeather() {
    const apiKey = "e76150410b0772ec6c2eceddb4817bf6"; //  هنا جلبت الapi للطقس 
    const url = `https://api.openweathermap.org/data/2.5/weather?q=Gaza&appid=${apiKey}&units=metric`;

    try {
        let response = await fetch(url);
        let data = await response.json();
        document.getElementById("result").innerText = `درجة الحرارة: ${data.main.temp}°C`;
    } catch (error) {
        document.getElementById("result").innerText = "حدث خطأ في الاتصال";
    }
}